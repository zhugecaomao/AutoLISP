//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SaveBlock.rc
//
#define IDS_SAVEBLOCKTOORACLE_COMMAND   1
#define IDS_LOADBLOCKFROMORACLE_COMMAND 2
#define IDS_NOT_IN_MODEL_SPACE          3

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        2000
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         2000
#define _APS_NEXT_SYMED_VALUE           2000
#endif
#endif

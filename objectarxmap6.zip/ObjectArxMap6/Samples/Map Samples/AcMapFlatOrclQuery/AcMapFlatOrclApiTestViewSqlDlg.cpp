// AcMapFlatOrclApiTestViewSqlDlg.cpp : implementation file
//
///////////////////////////////////////////////////////////////////////////////
// (C) Copyright 2001 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//
// CREATED BY:
//	Hugues Wisniewski, June 2001
//
// DESCRIPTION:
// 	Implementation of class AcMapFlatOrclApiTestViewSqlDlg

#include "stdafx.h"
#include "AcMapFlatOrclApiTestViewSqlDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// AcMapFlatOrclApiTestViewSqlDlg dialog


//******************************************************************************************
AcMapFlatOrclApiTestViewSqlDlg::AcMapFlatOrclApiTestViewSqlDlg(
	const std::string& strDlgTitle, //title of the dialog box
	const std::string& strText, //value of the text to display
	CWnd* pParent) //parent window, can be NULL
	: CDialog(AcMapFlatOrclApiTestViewSqlDlg::IDD, pParent),
	m_strDlgTitle(strDlgTitle)
{
	//{{AFX_DATA_INIT(AcMapFlatOrclApiTestViewSqlDlg)
	m_strText = strText.c_str();
	//}}AFX_DATA_INIT
}


//******************************************************************************************
void AcMapFlatOrclApiTestViewSqlDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(AcMapFlatOrclApiTestViewSqlDlg)
	DDX_Control(pDX, IDC_STATIC_TITLE_TEXT, m_staticTitleText);
	DDX_Control(pDX, IDC_EDIT_TEXT, m_editText);
	DDX_Text(pDX, IDC_EDIT_TEXT, m_strText);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(AcMapFlatOrclApiTestViewSqlDlg, CDialog)
	//{{AFX_MSG_MAP(AcMapFlatOrclApiTestViewSqlDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// AcMapFlatOrclApiTestViewSqlDlg message handlers

//******************************************************************************************
BOOL AcMapFlatOrclApiTestViewSqlDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	SetWindowText(m_strDlgTitle.c_str());
	m_editText.SetTabStops(12);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

//******************************************************************************************
void AcMapFlatOrclApiTestViewSqlDlg::OnOK() 
{
	UpdateData(true);
	
	CDialog::OnOK();
}

//eof
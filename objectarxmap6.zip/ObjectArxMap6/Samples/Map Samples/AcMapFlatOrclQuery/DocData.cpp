///////////////////////////////////////////////////////////////////////////////
// (C) Copyright 2000 by Autodesk, Inc.
//                                                                           
// The information contained herein is confidential, proprietary to Autodesk, 
// Inc., and considered a trade secret as defined in section 499C of the      
// penal code of the State of California.  Use of this information by anyone  
// other than authorized employees of Autodesk, Inc. is granted only under a  
// written non-disclosure agreement, expressly prescribing the scope and      
// manner of such use.
//
// CREATED BY:
//	Hugues Wisniewski, June 2001
//
// DESCRIPTION:
// 	Implementation of class CDocData

#include "StdAfx.h"
#include "StdArx.h"

// The one and only document manager object
// You can use the DocVars object to retrieve
// document specific data throughout your application
AsdkDataManager<CDocData> DocVars;


//
// Implementation of the document data class.
//
CDocData::CDocData()
{
	// NOTE: DO NOT edit the following lines.
	//{{AFX_ARX_DATA_INIT(CDocData)
	//}}AFX_ARX_DATA_INIT

	// TODO: add your own initialization.

}

CDocData::~CDocData()
{
	// NOTE: DO NOT edit the following lines.
	//{{AFX_ARX_DATA_DEL(CDocData)
	//}}AFX_ARX_DATA_DEL

	// TODO: clean up.

}

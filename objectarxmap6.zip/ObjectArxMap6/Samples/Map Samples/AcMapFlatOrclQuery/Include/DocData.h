// docdata.h : include file for document specific data
//      an instance of this class is automatically created
//      and managed by the AsdkDataManager class
//      see the AsdkDmgr.h DocData.cpp for more datail
#if !defined(AFX_DOCDATA_H__60C00DA8_672C_11D5_95D0_0010B547D103__INCLUDED_)
#define AFX_DOCDATA_H__60C00DA8_672C_11D5_95D0_0010B547D103__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

////////////////////////////////////////////////////
//
// Here you can store the document / database
// related data.
//
///////////////////////////////////////////////////////////////////////////////
// (C) Copyright 2000 by Autodesk, Inc.
//                                                                           
// The information contained herein is confidential, proprietary to Autodesk, 
// Inc., and considered a trade secret as defined in section 499C of the      
// penal code of the State of California.  Use of this information by anyone  
// other than authorized employees of Autodesk, Inc. is granted only under a  
// written non-disclosure agreement, expressly prescribing the scope and      
// manner of such use.
//
// CREATED BY:
//	Hugues Wisniewski, June 2001
//
// DESCRIPTION:
// 	Declaration of class CDocData

class CDocData
{
public:
	CDocData();
	~CDocData();

	// NOTE: DO NOT edit the following lines.
	//{{AFX_ARX_DATA(CDocData)
	//}}AFX_ARX_DATA

	// TODO: here you can add your variables
	//       which depends on a document / database.

};

#endif

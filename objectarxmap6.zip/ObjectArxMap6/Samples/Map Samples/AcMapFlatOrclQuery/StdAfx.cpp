///////////////////////////////////////////////////////////////////////////////
// (C) Copyright 2000 by Autodesk, Inc.
//                                                                           
// The information contained herein is confidential, proprietary to Autodesk, 
// Inc., and considered a trade secret as defined in section 499C of the      
// penal code of the State of California.  Use of this information by anyone  
// other than authorized employees of Autodesk, Inc. is granted only under a  
// written non-disclosure agreement, expressly prescribing the scope and      
// manner of such use.
//
// CREATED BY:
//	Hugues Wisniewski, June 2001
//
// DESCRIPTION:
// 	Precompiled headers

// StdAfx.cpp : source file that includes just the standard includes
//  StdAfx.pch will be the pre-compiled header
//  StdAfx.obj will contain the pre-compiled type information

#include "StdAfx.h"


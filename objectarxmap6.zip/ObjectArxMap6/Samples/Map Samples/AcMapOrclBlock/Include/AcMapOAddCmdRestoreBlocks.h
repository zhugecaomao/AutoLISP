// AcMapOAddCmdRestoreBlocks.h: interface for the AcMapOAddCmdRestoreBlocks class.
//
// (C) Copyright 2001 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//
// CREATED BY:
// David Barbour, March 2001
//
// DESCRIPTION:
// 	Header for restore blocks functionality


#if !defined(AFX_ACMAPOADDCMDRESTOREBLOCKS_H__5A1ABDF2_F7DB_11D4_95B3_0010B547D103__INCLUDED_)
#define AFX_ACMAPOADDCMDRESTOREBLOCKS_H__5A1ABDF2_F7DB_11D4_95B3_0010B547D103__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//Include files
#include "docdata.h"


//*****************************************************************************             
// forward declarations
class AcDbDatabase;
class AcMapOracleConnection;
class ODatabase;


//*****************************************************************************             
// defines
const unsigned short BLOCKNAME_MAX_LEN = 255;

//*****************************************************************************             


#endif // !defined(AFX_ACMAPOADDCMDRESTOREBLOCKS_H__5A1ABDF2_F7DB_11D4_95B3_0010B547D103__INCLUDED_)


// StdAfx.h : include file for standard system include files,
//      or project specific include files that are used frequently,
//      but are changed infrequently

#if !defined(AFX_STDAFX_H__11FDDACB_59E4_11D5_96E1_0010B56FA9A3__INCLUDED_)
#define AFX_STDAFX_H__11FDDACB_59E4_11D5_96E1_0010B56FA9A3__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#pragma warning(disable: 4786)
//#pragma warning(disable: 4098)

#if defined(_DEBUG) && !defined(_FULLDEBUG_)
#define _DEBUG_WAS_DEFINED
#undef _DEBUG
#endif

#include <windows.h>

extern HINSTANCE _hdllInstance ;
// RX Includes
#include "acdb.h"               // acdb definitions
#include "rxregsvc.h"           // ARX linker
#include "dbapserv.h"           // Host application services
#include "aced.h"               // aced stuff
#include "adslib.h"             // RXADS definitions
#include "acdocman.h"           // MDI document manager

#ifndef ORACL_ORACLE
#include "oracl.h"
#endif
#include "AcMapOracleConnection.h"
#include "AcMapOracleExport.h"
#include "AcMapOracleQuery.h"
#include "AcMapOracleImport.h"
#include "AcMapOracleIdentification.h"


#ifdef _DEBUG_WAS_DEFINED
#define _DEBUG
#undef _DEBUG_WAS_DEFINED
#endif

//{{AFX_ARX_FUNC
void AcMapOAddCmdRestoreBlock();
void AcMapOAddCmdSaveBlock();
void AcMapOAddCmdStopSaveBlock();
//}}AFX_ARX_FUNC

#endif // !defined(AFX_STDAFX_H__11FDDACB_59E4_11D5_96E1_0010B56FA9A3__INCLUDED)

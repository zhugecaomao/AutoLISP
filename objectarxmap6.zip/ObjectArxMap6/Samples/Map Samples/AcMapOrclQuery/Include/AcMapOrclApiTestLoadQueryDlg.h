#if !defined(AFX_ACMAPORCLAPITESTLOADQUERYDLG_H__60C00DB6_672C_11D5_95D0_0010B547D103__INCLUDED_)
#define AFX_ACMAPORCLAPITESTLOADQUERYDLG_H__60C00DB6_672C_11D5_95D0_0010B547D103__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AcMapOrclApiTestLoadQueryDlg.h : header file
//
///////////////////////////////////////////////////////////////////////////////
// (C) Copyright 2001 by Autodesk, Inc. 
//
// Permission to use, copy, modify, and distribute this software in
// object code form for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appears in all copies and 
// that both that copyright notice and the limited warranty and
// restricted rights notice below appear in all supporting 
// documentation.
//
// AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
// AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF
// MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE.  AUTODESK, INC. 
// DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE
// UNINTERRUPTED OR ERROR FREE.
//
// Use, duplication, or disclosure by the U.S. Government is subject to 
// restrictions set forth in FAR 52.227-19 (Commercial Computer
// Software - Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)
// (Rights in Technical Data and Computer Software), as applicable.
//
// CREATED BY:
//	Hugues Wisniewski, June 2001
//
// DESCRIPTION:
// 	Declaration of class AcMapOrclApiTestLoadQueryDlg

#include "AcMapOrclApiTestResource.h"

/////////////////////////////////////////////////////////////////////////////
// AcMapOrclApiTestLoadQueryDlg dialog

class AcMapOrclApiTestLoadQueryDlg : public CDialog
{
// Construction
public:
	AcMapOrclApiTestLoadQueryDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(AcMapOrclApiTestLoadQueryDlg)
	enum { IDD = IDD_API_LOAD_QUERY };
	CListBox	m_listQueryNames;
	CString	m_strQueryName;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(AcMapOrclApiTestLoadQueryDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(AcMapOrclApiTestLoadQueryDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnDblclkListQueryNames();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ACMAPORCLAPITESTLOADQUERYDLG_H__60C00DB6_672C_11D5_95D0_0010B547D103__INCLUDED_)

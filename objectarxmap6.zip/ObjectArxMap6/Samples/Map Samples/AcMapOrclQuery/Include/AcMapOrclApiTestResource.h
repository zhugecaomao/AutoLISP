//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AcMapOrclApiTest.rc
//
#define IDS_PROJNAME                    100
#define IDD_API_IMPORT                  150
#define IDD_DESCRIBE_OD_TABLE           151
#define IDC_LIST_CONDITION_SAMPLES      200
#define IDD_API_CONNECT                 201
#define IDC_BTN_LIST_OD                 201
#define IDC_BTN_VIEW_SQL                202
#define IDD_API_INFORMATION             202
#define IDC_EDIT_WHERE_CLAUSE           203
#define IDC_EDIT_USER_NAME              204
#define IDC_BTN_DESCRIBE_OD_TABLE       204
#define IDC_EDIT_SERVICE                205
#define IDC_EDIT_PASSWORD               206
#define IDC_EDIT_TABLE_NAME             206
#define IDC_EDIT_TABLE_DESCRIPTION      207
#define IDC_STATIC_USER_NAME            208
#define IDC_BTN_DESCRIBE                208
#define IDC_STATIC_PASSWORD             209
#define IDC_EDIT_TABLENAME              209
#define IDC_STATIC_SERVICE              210
#define IDC_BTN_BLOCKS                  210
#define IDC_STATIC_WHERE_CLAUSE         211
#define IDC_STATIC_CONDITION_SAMPLES    212
#define IDC_STATIC_SELECT_FROM          213
#define IDC_STATIC_SERVICE_SCHEMA       1002
#define IDC_BTN_CONNECT                 1003
#define IDD_API_DISPLAY_TEXT            1007
#define IDD_API_LOAD_QUERY              1014
#define IDC_BTN_SAVE_QUERY              1016
#define IDC_BTN_LOAD_QUERY              1017
#define IDC_STATIC_TITLE_TEXT           1026
#define IDC_EDIT_TEXT                   1027
#define IDC_LIST_QUERY_NAMES            1062
#define IDC_STATIC_ORACLE_SERVICE_SCHEMA_GRP 1094
#define IDC_STATIC_IMPORT_SETTINGS      1097
#define IDD_API_VIEW_SQL                5011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         211
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

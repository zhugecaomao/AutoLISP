
Copyright (C) 1999 by Autodesk, Inc.

Permission to use, copy, modify, and distribute this software in 
object code form for any purpose and without fee is hereby granted, 
provided that the above copyright notice appears in all copies and 
that both that copyright notice and the limited warranty and 
restricted rights notice below appear in all supporting 
documentation.

AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF 
MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC. 
DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE 
UNINTERRUPTED OR ERROR FREE.

Use, duplication, or disclosure by the U.S. Government is subject 
to restrictions set forth in FAR 52.227-19 (Commercial Computer    
Software -- Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)    
(Rights in Technical Data and Computer Software), as applicable.


Trademarks

AutoCAD Map and ObjectARX are trademarks of Autodesk, Inc., in the 
USA and/or other countries.

All other brand names, product names or trademarks belong to 
their respective holders.


======================================================================
SAMPLE CODE for AutoCAD Map 2000 ObjectARX API
======================================================================

April 1999

These ObjectARX(TM) source code samples are designed to demonstrate 
the ObjectARX API to AutoCAD Map 2000. They are not polished, and 
they do not constitute full tutorials, but they will give you some 
ideas about using this API to customize and extend AutoCAD Map.


Loading the ObjectARX sample application
----------------------------------------

To load the sample application
1  Enter "ARX" on the Command Line of AutoCAD Map.
2  Choose Load, and then choose MapDemoApp.arx in the file browser.


Executing commands
------------------

MapDemoApp.arx adds a set of commands to AutoCAD Map. To execute a 
command, enter its name on the Command Line.


The commands
------------

EDITALIASES demonstrates all operations with ADE aliases. It lets you 
remove, update, or rename an alias; remove all aliases; or add a new 
one.

EDITDSET demonstrates operations with the ADE drawing set and the 
properties of source drawings. It lets you 
- Attach or detach, activate or deactivate a source drawing. 
- Edit transformation parameters, get information on symbol tables, 
  ASE LPNs and OD definitions in the specified source drawing. 
- Invoke EDITALISES command. 
- Preview the specified source drawing.
- Apply the current query in "preview", "report" or "draw" mode to 
  the specified source drawing. 
- Zoom drawing extents.

EDITQUERY demonstrates operations with ADE queries. It lets you 
define, execute, save, clear, or load a query either from the query 
library or an external file.

TESTEXPR demonstrates creating and executing AutoCAD Map expressions.

TESTOPTIONS demonstrates getting AutoCAD Map Options.

TESTQLIB demonstrates operations with the query library. It lets you 
add, edit, or remove a query category.

TESTRANGE demonstrates operations with the range table library. It 
lets you add, rename, or edit a range table.

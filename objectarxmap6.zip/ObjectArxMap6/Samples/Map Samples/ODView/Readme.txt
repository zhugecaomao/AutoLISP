
Copyright (C) 1999 by Autodesk, Inc.

Permission to use, copy, modify, and distribute this software in 
object code form for any purpose and without fee is hereby granted, 
provided that the above copyright notice appears in all copies and 
that both that copyright notice and the limited warranty and 
restricted rights notice below appear in all supporting 
documentation.

AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF 
MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC. 
DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE 
UNINTERRUPTED OR ERROR FREE.

Use, duplication, or disclosure by the U.S. Government is subject 
to restrictions set forth in FAR 52.227-19 (Commercial Computer    
Software -- Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)    
(Rights in Technical Data and Computer Software), as applicable.


Trademarks

AutoCAD Map and ObjectARX are trademarks of Autodesk, Inc., in the 
USA and/or other countries.

All other brand names, product names or trademarks belong to 
their respective holders.


======================================================================
SAMPLE CODE for AutoCAD Map 2000 ObjectARX API
======================================================================

April 1999

These ObjectARX(TM) source code samples are designed to demonstrate 
the ObjectARX API to AutoCAD Map 2000. They are not polished, and 
they do not constitute full tutorials, but they will give you some 
ideas about using this API to customize and extend AutoCAD Map.

Installation steps
------------------

1. Load the project into Developer Studio.

2. In the Project Settings, make sure the path is set up correctly in the C/C++ tab
   to have the Additional include diectories pointing to where you installed ObjectARX 2000
   and the Map ARX API. (For example C:\ObjectARX 2000\inc)

3. In the Project Settings, make sure the path is set up correctly in the Link tab
   to have the Additional library path pointing to where you installed ObjectARX 2000
   and the Map ARX API. (For example C:\ObjectARX 2000\lib)



Loading the ObjectARX sample application
----------------------------------------

To load the sample application
1. Enter "ARX" on the Command Line of AutoCAD Map.
2. Choose Load, and then choose ODView.arx in the file browser.
3. The ODView docking window should now be visible.


Using the sample
------------------

1. The ODView docking window should be visible.

2. Load the included drawing \dwg\object_data.dwg. NOTE: DO NOT ATTACH THE DRAWING TO THE PROJECT.
JUST OPEN IT FROM THE ACAD OPEN... MENU. (It would be easy to use AcMapDrawingSetReactor and update
the window when a drawing gets attached. That's something you could add to the sample.)
Once open, the UI in the docking window should be updated with the tables in the drawing and
an initial set of fields. (Another thing missing is MDI awareness. The sample does not switch
bewteen documents. This could be easily added.)

3. The UI has two drop down combo boxes. The one on the left turns tracking on and off. The
other is a list of OD Tables in the drawing. The check boxes next to the field names are
used as tool tips when selected.

4.Turn tracking on, select some of the check boxes next to the field names, and start
pointing at objects. The View should be updated with the OD info as well as any tool
tips you selected.

5. NOTE: Tool tips are tricky, but they do work. They seem to work best around dense groups
of objects.
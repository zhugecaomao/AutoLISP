#if !defined(AFX_SAMPLELISTVIEW_H__F26072D8_75A6_11D2_B995_0060B0A2F691__INCLUDED_)
#define AFX_SAMPLELISTVIEW_H__F26072D8_75A6_11D2_B995_0060B0A2F691__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// SampleListView.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSampleListView view

class CSampleListView : public CListView
{
public:
	CSampleListView();           // protected constructor used by dynamic creation
	virtual ~CSampleListView();
	DECLARE_DYNCREATE(CSampleListView)

// Attributes
public:

// Operations
public:
	void Init();
	void SetColumns( LPSTR pColNames, int iColCt, int *piColWi );
	void AddRow(LPSTR pRowText);
	BOOL AddItem(int nItem, int nSubItem, LPCTSTR strItem);
	void ClearList();
	void SetLVCheck(int ItemIndex, BOOL bCheck);
	BOOL UseToolTips();
	void GetCheckedItems(CStringArray &strArray);
	BOOL IsItemChecked(int iItem);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSampleListView)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	protected:
	virtual void OnDraw(CDC* pDC);      // overridden to draw this view
	//}}AFX_VIRTUAL

// Implementation
protected:
	//virtual ~CSampleListView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

	// Generated message map functions
protected:
	//{{AFX_MSG(CSampleListView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnItemchanged(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SAMPLELISTVIEW_H__F26072D8_75A6_11D2_B995_0060B0A2F691__INCLUDED_)

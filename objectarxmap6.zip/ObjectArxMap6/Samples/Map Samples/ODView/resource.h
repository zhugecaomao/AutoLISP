//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ODView.rc
//
#define IDR_MAINFRAME                   101
#define ID_VIEW_OBJECTDATA              102
#define IDC_ONOFF_COMBO                 103
#define IDC_ODTABLE_COMBO               104
#define ID_POPUP_DOCK                   1002
#define ID_POPUP_HIDE                   1003
#define IDS_DOCKTITLE                   1004
#define ID_VIEW_ODTABLES                40002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40003
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

// stdafx.cpp : source file that includes just the standard includes
//	Trayex.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#ifdef _DEBUG
#define _DEBUG_WAS_DEFINED
#undef _DEBUG
#endif
#include "stdafx.h"
#ifdef _DEBUG_WAS_DEFINED
#define _DEBUG
#undef _DEBUG_WAS_DEFINED
#endif


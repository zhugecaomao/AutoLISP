
// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the PROPALT_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// PROPALT_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#ifdef PROPALT_EXPORTS
#define PROPALT_API __declspec(dllexport)
#else
#define PROPALT_API __declspec(dllimport)
#endif

// This class is exported from the PropAlt.dll
class PROPALT_API CPropAlt {
public:
	CPropAlt(void);
	// TODO: add your methods here.
};

extern PROPALT_API int nPropAlt;

PROPALT_API int fnPropAlt(void);


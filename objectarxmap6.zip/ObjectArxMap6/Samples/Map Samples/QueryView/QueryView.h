// QueryView.h
/////////////////////////////////////////////////////////


// function declaration of your new AutoCAD functions
void qryview();


// TODO: add other functions and variables




// END


Copyright (C) 1999 by Autodesk, Inc.

Permission to use, copy, modify, and distribute this software in 
object code form for any purpose and without fee is hereby granted, 
provided that the above copyright notice appears in all copies and 
that both that copyright notice and the limited warranty and 
restricted rights notice below appear in all supporting 
documentation.

AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS. 
AUTODESK SPECIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF 
MERCHANTABILITY OR FITNESS FOR A PARTICULAR USE. AUTODESK, INC. 
DOES NOT WARRANT THAT THE OPERATION OF THE PROGRAM WILL BE 
UNINTERRUPTED OR ERROR FREE.

Use, duplication, or disclosure by the U.S. Government is subject 
to restrictions set forth in FAR 52.227-19 (Commercial Computer    
Software -- Restricted Rights) and DFAR 252.227-7013(c)(1)(ii)    
(Rights in Technical Data and Computer Software), as applicable.


Trademarks

AutoCAD Map and ObjectARX are trademarks of Autodesk, Inc., in the 
USA and/or other countries.

All other brand names, product names or trademarks belong to 
their respective holders.


======================================================================
SAMPLE CODE for AutoCAD Map 2000 ObjectARX API
======================================================================

April 1999

These ObjectARX(TM) source code samples are designed to demonstrate 
the ObjectARX API to AutoCAD Map 2000. They are not polished, and 
they do not constitute full tutorials, but they will give you some 
ideas about using this API to customize and extend AutoCAD Map.

Installation steps
------------------

1) Load the project into Developer Studio.

2) In the Project Settings, make sure the path is set up correctly in the C/C++ tab
   to have the Additional include directories pointing to where you installed ObjectARX 2000
   and the Map ARX API. (For example C:\ObjectARX 2000\inc)

3) In the Project Settings, make sure the path is set up correctly in the Link tab
   to have the Additional library path pointing to where you installed ObjectARX 2000
   and the Map ARX API. (For example C:\ObjectARX 2000\lib)



Loading the ObjectARX sample application
----------------------------------------

To load the sample application
1  Enter "ARX" on the Command Line of AutoCAD Map.
2  Choose Load, and then choose QueryView.arx in the file browser.
3. Type the command "qryview". The QueryView docking window should now be visible.


Using the sample
------------------

The sample extends the functionality of the Project Workspace for Map, in that it
shows all the information stored within queries in a Tree Control. The application uses
reactors to get notification that a Query Category or Query has been added or modified
in some way.

In the Maps Project Workspace Window, add some Query Categories and save Queries to the newly
created categories. The QueryView window will be updated, showing all the new categories and
queries contained within.

One problem this sample highlights is re-entrancy into the internals of Map when you get a
reactor notification. If Map is busy, (found out by calling AcMapProject::IsMapActive()),
you will not be able to access some portions of Map via the API. To overcome this, the sample
posts a message when a reactor message is received and starts a timer. The timer then polls Map
every half second to see if it's busy. There a other ways you could implement this, but this works
well for this example.




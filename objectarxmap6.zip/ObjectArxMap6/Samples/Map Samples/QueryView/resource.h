//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by QueryView.rc
//
#define IDD_FORMVIEW                    101
#define IDS_PROPSHT_CAPTION             102
#define IDD_PROPPAGE1                   103
#define IDS_DOCKTITLE                   103
#define IDD_PROPPAGE2                   104
#define IDB_TAB_IMAGES                  130
#define IDR_QL_POPUP_DLG                130
#define IDB_QRY_TREE_IMAGES             131
#define IDB_ERROR_TREE_IMAGES           133
#define IDR_QCAT_POPUP_DLG              134
#define IDR_QRY_POPUP_DLG               136
#define IDR_CURQRY_POPUP_DLG            137
#define IDC_TREE1                       1000
#define IDC_TREE2                       1001
#define ID_POPUP_DOCK                   32784
#define ID_POPUP_HIDE                   32785
#define ID_GFX_FORMATHEADER             32801
#define ID_POPUP_NEWCATEGORY            40001
#define ID_POPUP_ADMINISTRATION         40002
#define ID_QRY_POPUP_EXECUTEASPREVIEW   40004
#define ID_QRY_POPUP_EXECUTEASDEFINED   40005
#define ID_QCAT_POPUP_DEFINE            40011
#define ID_QCAT_POPUP_RENAME            40012
#define ID_QCAT_POPUP_DELETE            40013
#define ID_CURQRY_POPUP_DEFINE          40014
#define ID_CURQRY_POPUP_EXECUTEASPREVIEW 40015
#define ID_CURQRY_POPUP_EXECUTEASDEFINED 40016
#define ID_CURQRY_POPUP_CLEAR           40017
#define ID_QRY_POPUP_SETASCURRENT       40018
#define ID_QRY_POPUP_EDIT               40019
#define ID_QRY_POPUP_DELETE             40020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40021
#define _APS_NEXT_CONTROL_VALUE         1021
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

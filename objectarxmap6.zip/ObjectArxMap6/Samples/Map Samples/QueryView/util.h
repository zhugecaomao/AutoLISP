#ifndef __UTIL_H__
#define __UTIL_H__


char* getClassIdString(AcMap::EClassId id);
char* getPropertyTypeString(AcMap::EPropertyType type);
char* getPropertyConditionString(AcMap::EConditionOperator condition);
char* getDataTypeString(AcMap::EDataQueryType type);

#endif

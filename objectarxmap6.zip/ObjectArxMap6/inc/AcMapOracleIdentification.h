// AcMapOracleIdentification.h: interface for the AcMapOracleIdentification class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ACMAPORACLEIDENTIFICATION_H__484F3AE2_3039_11D5_96DE_0010B56FA9A3__INCLUDED_)
#define AFX_ACMAPORACLEIDENTIFICATION_H__484F3AE2_3039_11D5_96DE_0010B56FA9A3__INCLUDED_

#pragma once

#include "dbid.h"	//for AcDbObjectId

class AcMapOracleConnection;
class AcMapOracleConnection;

#include "OracleExports.h"	//for ORCL_API

class ORCL_API AcMapOracleIdentification  
{
public:
	AcMapOracleIdentification (AcMapOracleConnection &connection);
	bool Init(AcDbObjectId acadId);
	bool Init(unsigned long oracleId);
	virtual ~ AcMapOracleIdentification ();

	unsigned long GetOracleID() const;
	AcDbObjectId GetAcadID(AcDbDatabase *pDb);
private:
	AcMapOracleConnection &m_connection;
	AcDbObjectId m_acadId;
	long m_lOracleId;
};

#endif // !defined(AFX_ACMAPORACLEIDENTIFICATION_H__484F3AE2_3039_11D5_96DE_0010B56FA9A3__INCLUDED_)

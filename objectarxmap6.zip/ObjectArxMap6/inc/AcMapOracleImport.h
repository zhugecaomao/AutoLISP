// AcMapOracleImport.h: interface for the AcMapOracleImport class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ACMAPORACLEIMPORT_H__484F3AE3_3039_11D5_96DE_0010B56FA9A3__INCLUDED_)
#define AFX_ACMAPORACLEIMPORT_H__484F3AE3_3039_11D5_96DE_0010B56FA9A3__INCLUDED_

#pragma once

class AcMapOracleConnection;
class AcMapOracleQuery;
class AcMapOImport;
class AcMapOQuerySqlStatement;

#include "OracleExports.h"	//for ORCL_API

class ORCL_API AcMapOracleImport  
{
public:
	AcMapOracleImport(AcMapOracleConnection &connection);
	virtual ~AcMapOracleImport();

	bool CheckImport();
	bool Import(const AcMapOracleQuery &kpcSQL, bool& bEditMode);
private:
	
	AcMapOImport *m_pImport;
	AcMapOracleConnection &m_connection;
};

#endif // !defined(AFX_ACMAPORACLEIMPORT_H__484F3AE3_3039_11D5_96DE_0010B56FA9A3__INCLUDED_)

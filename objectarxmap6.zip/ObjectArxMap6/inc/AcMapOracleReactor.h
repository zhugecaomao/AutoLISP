// AcMapOracleReactor.h: interfaces for the reactor classes.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ACMAPORACLEREACTOR_H__6B33C591_2E08_11D5_96DA_0010B56FA9A3__INCLUDED_)
#define AFX_ACMAPORACLEREACTOR_H__6B33C591_2E08_11D5_96DA_0010B56FA9A3__INCLUDED_

#pragma once

#include <vector>

class AcMapOracleConnectionReactor  
{
public:
	AcMapOracleConnectionReactor() {}
	virtual ~AcMapOracleConnectionReactor() {}

	virtual void Connected() {}
	virtual void BeforeConnect() {}
	virtual void SchemaChanged() {}
	virtual void BeforeSchemaChange() {}
	virtual void Disconnected() {}
	virtual void BeforeDisconnect() {}
};

class AcMapOracleImportReactor
{
public:
	AcMapOracleImportReactor () {}
	virtual ~AcMapOracleImportReactor () {}

	virtual void BeforeRecordImport(const ODynaset &Dynaset) {}
	virtual void RecordImported(const ODynaset &Dynaset, AcDbEntity *pAcDbEntity) {}
	virtual void RecordRejected(const ODynaset &Dynaset) {}
};

class AcMapOracleExportReactor
{
public:
	AcMapOracleExportReactor () {}
	virtual ~AcMapOracleExportReactor () {}

	virtual void BeforeObjectCached(AcDbEntity *pObj) {}
	virtual void ObjectCached(AcDbEntity *pObj, unsigned long lOracleID) {}
	virtual void ObjectRejected(AcDbEntity *pObj) {}
	virtual void BeforeObjectsExported(std::vector<unsigned long> &vOracleIDs) {}
	virtual void ObjectsExported(std::vector<unsigned long> &vOracleIDs) {}
};

#endif // !defined(AFX_ACMAPORACLEREACTOR_H__6B33C591_2E08_11D5_96DA_0010B56FA9A3__INCLUDED_)

// AdMapOracleImport.h: interface for the AcMapOSEImport class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ACMAPORACLEIMPORT_H__484F3AE3_3039_11D5_96DE_0010B56FA9A3__INCLUDED_)
#define AFX_ACMAPORACLEIMPORT_H__484F3AE3_3039_11D5_96DE_0010B56FA9A3__INCLUDED_

#pragma once

class AcMapOSEConnection;
class AcMapOSEQuery;
class AcMapOImport;
class AcMapOQuerySqlStatement;

#include "OracleExports.h"	//for ORCL_API

class ORCL_API AcMapOSEImport  
{
public:
	AcMapOSEImport(AcMapOSEConnection &connection);
	virtual ~AcMapOSEImport();

	bool Import(const AcMapOSEQuery &kpcSQL);
private:
	
	AcMapOImport *m_pImport;
	AcMapOSEConnection &m_connection;
};

#endif // !defined(AFX_ACMAPORACLEIMPORT_H__484F3AE3_3039_11D5_96DE_0010B56FA9A3__INCLUDED_)

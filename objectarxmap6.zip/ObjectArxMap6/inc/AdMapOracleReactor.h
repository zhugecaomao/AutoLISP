// AcMapOracleReactor.h: interfaces for the reactor classes.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ACMAPORACLEREACTOR_H__6B33C591_2E08_11D5_96DA_0010B56FA9A3__INCLUDED_)
#define AFX_ACMAPORACLEREACTOR_H__6B33C591_2E08_11D5_96DA_0010B56FA9A3__INCLUDED_

#pragma once

#include <vector>

class AcMapOSEConnectionReactor  
{
public:
	AcMapOSEConnectionReactor() {}
	virtual ~AcMapOSEConnectionReactor() {}

	virtual void Connected() {}
	virtual void BeforeConnect() {}
	virtual void SchemaChanged() {}
	virtual void BeforeSchemaChange() {}
	virtual void Disconnected() {}
	virtual void BeforeDisconnect() {}
};

class AcMapOSEImportReactor
{
public:
	AcMapOSEImportReactor () {}
	virtual ~AcMapOSEImportReactor () {}

	virtual void BeforeRecordImport(const ODynaset &Dynaset) {}
	virtual void RecordImported(const ODynaset &Dynaset, AcDbEntity *pAcDbEntity) {}
	virtual void RecordRejected(const ODynaset &Dynaset) {}
};

class AcMapOSEExportReactor
{
public:
	AcMapOSEExportReactor () {}
	virtual ~AcMapOSEExportReactor () {}

	virtual void BeforeObjectCached(AcDbEntity *pObj) {}
	virtual void ObjectCached(AcDbEntity *pObj, OValue oracleID) {}
	virtual void ObjectRejected(AcDbEntity *pObj) {}
	virtual void BeforeObjectsExported(std::vector<OValue> &vOracleIDs) {}
	virtual void ObjectsExported(std::vector<OValue> &vOracleIDs) {}
};

#endif // !defined(AFX_ACMAPORACLEREACTOR_H__6B33C591_2E08_11D5_96DA_0010B56FA9A3__INCLUDED_)

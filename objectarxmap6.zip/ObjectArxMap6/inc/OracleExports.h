#ifdef ACMAPORCL_EXPORTS
#define ORCL_API __declspec(dllexport)
#else
#define ORCL_API __declspec(dllimport)
#endif
